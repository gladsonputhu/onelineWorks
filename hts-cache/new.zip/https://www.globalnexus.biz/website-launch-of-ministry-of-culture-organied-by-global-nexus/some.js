		<!doctype html>
		<html lang="en-US" prefix="og: http://ogp.me/ns#">
		<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		
		<link rel="shortcut icon" href="https://www.globalnexus.biz/wp-content/themes/globalnexus/images/favicon.ico" alt="Global Nexus Favicon" />
		
		<script>
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-52788762-1', 'auto');
            ga('send', 'pageview');

        </script>

		<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Open+Sans:300,400,600,700" rel="stylesheet">

		<link rel="stylesheet" href="https://www.globalnexus.biz/wp-content/cache/minify/7eb5e.css" media="all" />
<title>Page not found -</title>

<!-- This site is optimized with the Yoast SEO plugin v7.8 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found -" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found -" />
<script type='application/ld+json'>{"@context":"https:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"@id":"https:\/\/www.globalnexus.biz\/","name":"Home"}},{"@type":"ListItem","position":2,"item":{"@id":null,"name":"Error 404: Page not found"}}]}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link href='https://cdn.shortpixel.ai' rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="https://www.globalnexus.biz/feed/" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="https://www.globalnexus.biz/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.globalnexus.biz\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.15"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		





<link rel='stylesheet' id='owl_carousel_css-css'  href='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='owl_theme_css-css'  href='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css?ver=1.0.0' type='text/css' media='all' />

<script src="https://www.globalnexus.biz/wp-content/cache/minify/62d70.js"></script>



<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js?ver=1.0.0'></script>
<script src="https://www.globalnexus.biz/wp-content/cache/minify/3fa12.js"></script>


<link rel='https://api.w.org/' href='https://www.globalnexus.biz/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.globalnexus.biz/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.globalnexus.biz/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.15" />
<!-- <meta name="NextGEN" version="3.0.1" /> -->
		<script>
		jQuery(document).ready(function ($){
		jQuery('#menu-main-menu > li.menu-item-has-children').addClass('dropdown');
		jQuery('.menu-item-has-children .sub-menu').addClass('dropdown-menu');

		jQuery('#menu-main-menu .menu-item-has-children .sub-menu > .menu-item-has-children ').addClass('dropdown-submenu');

		$('#menu-main-menu > li.menu-item-has-children > a ').addClass('dropdown-toggle');
		$('#menu-main-menu > li.menu-item-has-children > a').attr('data-toggle','dropdown');
		$('#menu-main-menu > li.menu-item-has-children > a').append('<span class="fa fa-angle-down"></span>');

		$('#menu-main-menu > li.menu-item-has-children > .sub-menu.dropdown-menu > li.menu-item-has-children > a').addClass('dropdown-toggle shailly');
		$('#menu-main-menu > li.menu-item-has-children > .sub-menu.dropdown-menu > li.menu-item-has-children > a').attr('data-toggle','dropdown');
		$('#menu-main-menu > li.menu-item-has-children > .sub-menu.dropdown-menu > li.menu-item-has-children > a').attr('aria-expanded','true');
		$('#menu-main-menu > li.menu-item-has-children > .sub-menu.dropdown-menu > li.menu-item-has-children > a').append('<span class="fa fa-angle-down"></span>');
		
		$('.search-form .search-field').attr('required','required');
		
		});
		</script>
		
		 <!--Start of Zopim Live Chat Script-->
        <script type="text/javascript">
            window.$zopim || (function (d, s) {
                var z = $zopim = function (c) {
                    z._.push(c)
                }, $ = z.s =
                        d.createElement(s), e = d.getElementsByTagName(s)[0];
                z.set = function (o) {
                    z.set.
                            _.push(o)
                };
                z._ = [];
                z.set._ = [];
                $.async = !0;
                $.setAttribute("charset", "utf-8");
                $.src = "//v2.zopim.com/?3I4KkD3ssxI2e1i8CTUhbTCHcKPN1naA";
                z.t = +new Date;
                $.
                        type = "text/javascript";
                e.parentNode.insertBefore($, e)
            })(document, "script");
        </script>
        <!--End of Zopim Live Chat Script-->
		
		
		
		</head>

		<body class="error404 hfeed">
		<!-- header -->
		<header id="masthead" class="site-header">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-sm-12 col-xs-12">
							<div class="navbar-header">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
																<a class="navbar-brand" href="https://www.globalnexus.biz" title="Global Nexus"><noscript><img src="https://cdn.shortpixel.ai/client/q_glossy,ret_img/https://www.globalnexus.biz/wp-content/uploads/2017/11/Global-Nexus-Logo-1.png" alt="Global Nexus" class="img-responsive"></noscript><img src='https://cdn.shortpixel.ai/client/q_lqip,ret_wait/https://www.globalnexus.biz/wp-content/uploads/2017/11/Global-Nexus-Logo-1.png' data-src="https://cdn.shortpixel.ai/client/q_glossy,ret_img/https://www.globalnexus.biz/wp-content/uploads/2017/11/Global-Nexus-Logo-1.png" alt="Global Nexus" class="lazyload img-responsive"></a>
							</div>
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<div class="menu-main-menu-container"><ul id="menu-main-menu" class="nav navbar-nav navbar-right"><li id="menu-item-2395" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-2395"><a href="https://www.globalnexus.biz/">Home</a></li>
<li id="menu-item-2466" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2466"><a href="https://www.globalnexus.biz/core-team/">Core Team</a></li>
<li id="menu-item-2626" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2626"><a href="https://www.globalnexus.biz/services/">Services</a></li>
<li id="menu-item-2653" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-2653"><a href="https://www.globalnexus.biz/blog/">Blog</a></li>
<li id="menu-item-4645" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4645"><a href="https://www.globalnexus.biz/clients/">Our Clients</a></li>
<li id="menu-item-4644" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4644"><a href="#">Gallery</a>
<ul class="sub-menu">
	<li id="menu-item-4646" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4646"><a href="https://www.globalnexus.biz/our-events/">Our Events</a></li>
	<li id="menu-item-6756" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6756"><a href="https://www.globalnexus.biz/our-event-videos/">Event Videos</a></li>
</ul>
</li>
<li id="menu-item-2477" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2477"><a href="https://www.globalnexus.biz/contact/">Contact Us</a></li>
</ul></div>							</div>
						</div>
					</div>
				</div>
			</nav>
		</header>
		<!-- /header -->

<section id="innerBanner" style="background:url(https://www.globalnexus.biz/wp-content/themes/globalnexus/images/common-banner.jpg) no-repeat top center;">
			<div class="innerBannerContent">
				<div class="outer">
					<div class="inner">
						<div class="container">
							<div class="row">
								<div class="col-lg-12 col-sm-12 col-xs-12">
									<h1>404</h1>
									<ol class="breadcrumb">
										<li><a href="https://www.globalnexus.biz">Home</a></li>
										<li class="active">404</li>
									</ol>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		

		<section id="about">
		<div class="container">
		<div class="row">
		<div class="col-lg-10 col-sm-12 col-xs-12 col-lg-offset-1 col-sm-ofsfet-0 col-xs-offset-0">
		<h2>404</h2>
		<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>

		<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
		</div>
		</div>
		</div>
		</section>

<!-- footer -->
<footer id="colophon" class="site-footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-sm-4 col-xs-12 footer-link">
				<h4>QUICK LINKs</h4>
				
				<div class="menu-footer-menu-container"><ul class="footerLinks"><li id="menu-item-2602" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2602"><a href="https://www.globalnexus.biz/core-team/">Core Team</a></li>
<li id="menu-item-2627" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2627"><a href="https://www.globalnexus.biz/services/">Services</a></li>
<li id="menu-item-2645" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2645"><a href="https://www.globalnexus.biz/career/">Career</a></li>
<li id="menu-item-2629" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2629"><a href="https://www.globalnexus.biz/what-we-do/event-management-companies/">Event Management</a></li>
<li id="menu-item-2610" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2610"><a href="https://www.globalnexus.biz/contact/">Contact Us</a></li>
<li id="menu-item-2607" class="request-quote menu-item menu-item-type-custom menu-item-object-custom menu-item-2607"><a href="#">Request a quote</a></li>
<li id="menu-item-2633" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2633"><a href="https://www.globalnexus.biz/sitemap/">Sitemap</a></li>
</ul></div>			</div>
			<div class="col-lg-4 col-sm-4 col-xs-12">
				<div class="connectUs">
										<h4>Contact us</h4>					<ul class="contactDetails">
<li class="address"><a href="https://www.google.com/maps/dir//28.589156,77.302044/@28.589156,77.302044,16z?hl=en-GB" target="_blank">B – 357A, Opposite Eastend Apartment<br />
New Ashok Nagar, New Delhi – 110096, India</a></li>
<li class="conatcNumber"><a href="tel:+91-9899966124">+91- 9899966124</a>, <a href="tel:+91-9560841559">+91- 9560841559</a></li>
<li class="emailAddress"><a href="mailto:bhupendra@globalnexus.biz">bhupendra@globalnexus.biz</a><br />
<a href="mailto:sumit@globalnexus.biz">sumit@globalnexus.biz</a></li>
</ul>
				</div>
			</div>
			<div class="col-lg-4 col-sm-4 col-xs-12">
				<div class="newsletter">
										<h4>Stay Updated</h4>					<form method="post" action="https://www.globalnexus.biz/?na=s" class="newsletter" style="">
<input type="hidden" name="nlang" value="">
<div class="tnp-field tnp-field-email"><input class="tnp-email" type="email" name="ne" value=""required></div>
<div class="tnp-field tnp-field-button"><input class="tnp-button" type="submit" value=" "></div></form>				</div>
				<div class="social">
									  <h4>Follow Us</h4>					<ul class="sociallinks">
					<li><a href=" https://www.facebook.com/global.nexus" target="_blank"><i class="fa fa-facebook"></i></a></li>					<li><a href=" http://www.twitter.com/globalnexus1" target="_blank"><i class="fa fa-twitter"></i></a></li>					<li><a href=" https://plus.google.com/+GlobalnexusBiz" target="_blank"><i class="fa fa-google-plus"></i></a></li>					<li><a href=" http://www.linkedin.com/company/global-nexus" target="_blank"><i class="fa fa-linkedin"></i></a></li>					</ul>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-xs-12">
								<div class="copyright" style="padding:0;">
					<div class="col-lg-6 col-sm-9 col-xs-12  text-left bottom-copy-content" style="padding: 30px 0px;">
					Copyright &copy; 2019 globalnexus.biz. All rights reserved.					</div>
					<div class="col-lg-6 col-sm-3 col-xs-12  text-right bottom-copy-content" style="padding: 30px 0px;">
					Website by <a href="http://ishir.com/" target="_blank" style="color:#fff;">ISHIR</a>
					</div>		
				</div>
				
			</div>
		</div>
	</div>
</footer>
<!-- /footer -->

<div class="modal fade" id="quote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h2>Request a Quote</h2>
				<div class="qouteForm">
				<div role="form" class="wpcf7" id="wpcf7-f2630-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/website-launch-of-ministry-of-culture-organied-by-global-nexus/some.js#wpcf7-f2630-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="2630" />
<input type="hidden" name="_wpcf7_version" value="5.0.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f2630-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
</div>
<div class="row">
<div class="col-gl-12 col-sm-12 col-xs-12">
<label for="fullname">Full Name <span>*</span></label><br />
<span class="wpcf7-form-control-wrap full-name"><input type="text" name="full-name" value="" size="40" maxlength="100" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span>
</div>
</div>
<div class="row">
<div class="col-gl-12 col-sm-12 col-xs-12">
<label for="email">E-mail <span>*</span></label><br />
 <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" maxlength="100" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span>
</div>
</div>
<div class="row">
<div class="col-gl-12 col-sm-12 col-xs-12">
<label for="mobilenumber">Mobile Number <span>*</span></label><br />
<span class="wpcf7-form-control-wrap mobile-number"><input type="text" name="mobile-number" value="" size="40" maxlength="15" minlength="10" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required phone-number" aria-required="true" aria-invalid="false" /></span>
</div>
</div>
<div class="row">
<div class="col-gl-12 col-sm-12 col-xs-12">
<label for="mobilenumber">Message</label><br />
<span class="wpcf7-form-control-wrap message"><textarea name="message" cols="40" rows="10" maxlength="1000" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span>
</div>
</div>
<div class="row" style="margin-bottom: 20px;">
<div class="col-lg-6 col-sm-6 col-xs-12">
<div class="wpcf7-form-control-wrap"><div data-sitekey="6LfX6VUUAAAAAPZsSxaVh7SJcni1RbEeUFrji1Ee" class="wpcf7-form-control g-recaptcha wpcf7-recaptcha"></div>
<noscript>
	<div style="width: 302px; height: 422px;">
		<div style="width: 302px; height: 422px; position: relative;">
			<div style="width: 302px; height: 422px; position: absolute;">
				<iframe src="https://www.google.com/recaptcha/api/fallback?k=6LfX6VUUAAAAAPZsSxaVh7SJcni1RbEeUFrji1Ee" frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;">
				</iframe>
			</div>
			<div style="width: 300px; height: 60px; border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px;">
				<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;">
				</textarea>
			</div>
		</div>
	</div>
</noscript>
</div>
</div>
</div>
<div class="row">
<div class="col-gl-12 col-sm-12 col-xs-12 text-center">
<input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit orangeBtn" /><input type="reset" value="Reset" class="grayBtn">
</div>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
var recaptchaWidgets = [];
var recaptchaCallback = function() {
	var forms = document.getElementsByTagName( 'form' );
	var pattern = /(^|\s)g-recaptcha(\s|$)/;

	for ( var i = 0; i < forms.length; i++ ) {
		var divs = forms[ i ].getElementsByTagName( 'div' );

		for ( var j = 0; j < divs.length; j++ ) {
			var sitekey = divs[ j ].getAttribute( 'data-sitekey' );

			if ( divs[ j ].className && divs[ j ].className.match( pattern ) && sitekey ) {
				var params = {
					'sitekey': sitekey,
					'type': divs[ j ].getAttribute( 'data-type' ),
					'size': divs[ j ].getAttribute( 'data-size' ),
					'theme': divs[ j ].getAttribute( 'data-theme' ),
					'badge': divs[ j ].getAttribute( 'data-badge' ),
					'tabindex': divs[ j ].getAttribute( 'data-tabindex' )
				};

				var callback = divs[ j ].getAttribute( 'data-callback' );

				if ( callback && 'function' == typeof window[ callback ] ) {
					params[ 'callback' ] = window[ callback ];
				}

				var expired_callback = divs[ j ].getAttribute( 'data-expired-callback' );

				if ( expired_callback && 'function' == typeof window[ expired_callback ] ) {
					params[ 'expired-callback' ] = window[ expired_callback ];
				}

				var widget_id = grecaptcha.render( divs[ j ], params );
				recaptchaWidgets.push( widget_id );
				break;
			}
		}
	}
};

document.addEventListener( 'wpcf7submit', function( event ) {
	switch ( event.detail.status ) {
		case 'spam':
		case 'mail_sent':
		case 'mail_failed':
			for ( var i = 0; i < recaptchaWidgets.length; i++ ) {
				grecaptcha.reset( recaptchaWidgets[ i ] );
			}
	}
}, false );
</script>
<noscript><style>.lazyload{display:none;}</style></noscript><script data-noptimize="1">window.lazySizesConfig=window.lazySizesConfig||{};window.lazySizesConfig.loadMode=1;</script><script async src="https://www.globalnexus.biz/wp-content/cache/minify/f9fb9.js"></script>
<script data-noptimize="1">function c_webp(A){var n=new Image;n.onload=function(){var e=0<n.width&&0<n.height;A(e)},n.onerror=function(){A(!1)},n.src='data:image/webp;base64,UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA=='}function s_webp(e){window.supportsWebP=e}c_webp(s_webp);document.addEventListener('lazybeforeunveil',function({target:c}){supportsWebP&&['data-src','data-srcset'].forEach(function(a){attr=c.getAttribute(a),null!==attr&&c.setAttribute(a,attr.replace(/\/client\//,'/client/to_webp,'))})});</script><script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.globalnexus.biz\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script src="https://www.globalnexus.biz/wp-content/cache/minify/25eda.js"></script>

<script type='text/javascript'>
/* <![CDATA[ */
var newsletter = {"messages":{"email_error":"The email is not correct","name_error":"The name is not correct","surname_error":"The last name is not correct","profile_error":"A mandatory field is not filled in","privacy_error":"You must accept the privacy statement"},"profile_max":"20"};
/* ]]> */
</script>

<script src="https://www.globalnexus.biz/wp-content/cache/minify/58e19.js"></script>

<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&#038;render=explicit&#038;ver=2.0'></script>
<script>
jQuery(document).ready(function ($){
	$('.request-quote a').attr('data-toggle','modal');	
	$('.request-quote a').attr('data-target','#quote');
	$('.request-quote a').attr('href','javascript:void(0);');
	$('.tnp-email').addClass('form-control');	
	$('.tnp-email').attr('placeholder','Your Email');
});	
</script>
<script type="text/javascript">
/*
	By Osvaldas Valutis, www.osvaldas.info
	Available for use under the MIT License
*/

'use strict';

;( function ( document, window, index )
{
	var inputs = document.querySelectorAll( '.inputfile' );
	Array.prototype.forEach.call( inputs, function( input )
	{
		var label	 = input.nextElementSibling,
			labelVal = label.innerHTML;

		input.addEventListener( 'change', function( e )
		{
			var fileName = '';
			if( this.files && this.files.length > 1 )
				fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
			else
				fileName = e.target.value.split( '\\' ).pop();

			if( fileName )
				label.querySelector( 'span' ).innerHTML = fileName;
			else
				label.innerHTML = labelVal;
		});

		// Firefox bug fix
		input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
		input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
	});
}( document, window, 0 ));
</script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('.wpcf7-file').change(function(e){
            var fileName = e.target.files[0].name;
            jQuery('.file_name').empty();
			jQuery('.file_name').append(fileName);
        });
    });
</script>
<link rel='stylesheet' id='dashicons-css'  href='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css' type='text/css' media='all' />
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js'></script>
<script>
jQuery(document).ready(function($){

$(".datepicker").datepicker({
changeMonth: true,
changeYear: true,
showButtonPanel: true,
yearRange: "-100:+0",
maxDate: new Date(),
dateFormat: 'mm/dd/yy',
});

$(".readonly").keydown(function(e){
e.preventDefault();
});


$('.phone-number').keyup(function ()
{
// Filter non-digits from input value.
this.value = this.value.replace(/[^\d\.\-+]/g,'');
});

});

</script>
<script>
document.addEventListener( 'wpcf7mailsent', function( event ) {
		    location = 'https://www.globalnexus.biz/thankyou/';
	}, false );
</script>
</body>
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Page Caching using disk: enhanced (Page is 404) 
Minified using disk

Served from: www.globalnexus.biz @ 2020-08-06 16:23:40 by W3 Total Cache
-->